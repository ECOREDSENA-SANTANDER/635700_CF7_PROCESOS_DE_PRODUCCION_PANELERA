function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5x459O3sapV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

